#ifndef MOTOR_H
#define MOTOR_H



void Motor_GPIO_Init(void);
void Motor_AllFon(void);
void Motor_AllFoff(void);

void Motor_AllRon(void);
void Motor_AllRoff(void);
















#endif
