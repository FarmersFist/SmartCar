#include "motor.h"

#include "gpio.h"

void Motor_GPIO_Init(){
	GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
//  __HAL_RCC_GPIOD_CLK_ENABLE();
//  __HAL_RCC_GPIOA_CLK_ENABLE();
//  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */

  /*Configure GPIO pins : PBPin PBPin */
  GPIO_InitStruct.Pin = MOTORA_F_Pin | MOTORA_R_Pin | MOTORB_F_Pin | MOTORB_R_Pin|MOTORD_F_Pin|MOTORD_R_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PBPin PBPin PBPin PBPin */
  GPIO_InitStruct.Pin = MOTORC_F_Pin | MOTORC_R_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
	
	Motor_AllFoff();
	Motor_AllRoff();
}

void Motor_AllFon(){
	HAL_GPIO_WritePin(GPIOA, MOTORA_F_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOA, MOTORB_F_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOB, MOTORC_F_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOA, MOTORD_F_Pin, GPIO_PIN_SET);
}

void Motor_AllFoff(){
	HAL_GPIO_WritePin(GPIOA, MOTORA_F_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOA, MOTORB_F_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOB, MOTORC_F_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOA, MOTORD_F_Pin, GPIO_PIN_RESET);
}

void Motor_AllRon(){
	HAL_GPIO_WritePin(GPIOA, MOTORA_R_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOA, MOTORB_R_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOB, MOTORC_R_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOA, MOTORD_R_Pin, GPIO_PIN_SET);
}

void Motor_AllRoff(){
	HAL_GPIO_WritePin(GPIOA, MOTORA_R_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOA, MOTORB_R_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOB, MOTORC_R_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOA, MOTORD_R_Pin, GPIO_PIN_RESET);
}